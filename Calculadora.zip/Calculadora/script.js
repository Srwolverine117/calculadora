// script.js
const display = document.querySelector(".display");
const buttons = document.querySelectorAll("button");

let currentInput = "";
let currentOperator = "";
let shouldClearDisplay = false;

buttons.forEach((button) => {
    button.addEventListener("click", () => {
        const buttonText = button.textContent;

        // Existing functionality for numbers and basic operators
        if (buttonText.match(/[0-9]/)) {
            if (shouldClearDisplay) {
                display.textContent = "";
                shouldClearDisplay = false;
            }
            display.textContent += buttonText;
        } else if (buttonText === "C") {
            display.textContent = "0";
            currentInput = "";
            currentOperator = "";
        } else if (buttonText === "=") {
            if (currentOperator && currentInput) {
                const result = calculate(parseFloat(currentInput), currentOperator, parseFloat(display.textContent));
                display.textContent = result;
                currentInput = result;
                currentOperator = "";
                shouldClearDisplay = true;
            }
        } else if (["+", "-", "*", "/"].includes(buttonText)) {
            currentOperator = buttonText;
            currentInput = display.textContent;
            shouldClearDisplay = true;
        } 
        // New scientific function handling
        else {
            switch(buttonText) {
                case "sin":
                    display.textContent = Math.sin(parseFloat(display.textContent)).toFixed(4);
                    break;
                case "cos":
                    display.textContent = Math.cos(parseFloat(display.textContent)).toFixed(4);
                    break;
                case "tan":
                    display.textContent = Math.tan(parseFloat(display.textContent)).toFixed(4);
                    break;
                case "log":
                    display.textContent = Math.log10(parseFloat(display.textContent)).toFixed(4);
                    break;
                case "ln":
                    display.textContent = Math.log(parseFloat(display.textContent)).toFixed(4);
                    break;
                case "√":
                    display.textContent = Math.sqrt(parseFloat(display.textContent)).toFixed(4);
                    break;
                case "^":
                    currentOperator = "^";
                    currentInput = display.textContent;
                    shouldClearDisplay = true;
                    break;
                case "!":
                    display.textContent = factorial(parseInt(display.textContent));
                    break;
                case "π":
                    display.textContent = Math.PI.toFixed(4);
                    break;
                case ".":
                    if (!display.textContent.includes(".")) {
                        display.textContent += ".";
                    }
                    break;
            }
        }
    });
});

function calculate(num1, operator, num2) {
    switch (operator) {
        case "+": return num1 + num2;
        case "-": return num1 - num2;
        case "*": return num1 * num2;
        case "/": 
            if (num2 !== 0) { 
                return num1 / num2; 
            } else { 
                return "Error"; 
            }
        case "^": return Math.pow(num1, num2);
        default: return num2;
    }
}

// Factorial function
function factorial(n) {
    if (n < 0) return NaN;
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}