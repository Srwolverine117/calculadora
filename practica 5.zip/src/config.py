class DevelopmentConfig():
    DEBUG = True
config = {"development": DevelopmentConfig}